package e1_onetoone_hibernate1.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import e1_onetoone_hibernate1.dto.PanCard;
import e1_onetoone_hibernate1.dto.Person;

public class PersonCrud {
	
	public EntityManager  getmanger() {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("radha");
		EntityManager manager=factory.createEntityManager();
		return manager;
	}
	
	
	public void savePerson(Person person,int cardid) {
		EntityManager manager=getmanger();
		PanCard card=manager.find(PanCard.class, cardid);
		if(card!=null) {
			person.setCard(card);
			EntityTransaction transaction=manager.getTransaction();
			transaction.begin();
			manager.persist(person);
			transaction.commit();
		}
		else
			System.out.println("provide valid pannnum");
		
		
	} 
	

}
